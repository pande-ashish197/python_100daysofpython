class HirstPainting:
    def __init__(self, timmy):
        self.timmy = timmy

    def draw_painting(self):
        self.timmy.dot(20)
        self.timmy.penup()
        self.timmy.forward(50)
        self.timmy.pendown()
