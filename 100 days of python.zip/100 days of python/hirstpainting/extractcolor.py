import turtle as t
import colorgram
import random
from hirstpainting.createhirstpainting import HirstPainting

t.colormode(255)
timmy = t.Turtle()
timmy.shape("turtle")
no_of_colors = 20
colors_list = []
colors = colorgram.extract('hirstspotpainting.jpg', no_of_colors)
for color in range(0, no_of_colors):
    color_name = colors[color]
    rgb = color_name.rgb
    colors_list.append((rgb.r, rgb.g, rgb.b))
print(colors_list)
for y in range(50, 550, 50):
    for _ in range(11):
        print(timmy.pos())
        use_color = random.choice(colors_list)
        print(use_color)
        timmy.color(use_color)
        painting = HirstPainting(timmy)
        painting.draw_painting()
    timmy.penup()
    timmy.setpos(0, y)
    timmy.pendown()
screen = t.Screen()
screen.bgcolor("orange")
screen.exitonclick()
