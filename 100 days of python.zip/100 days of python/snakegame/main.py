from turtle import Screen
from gameplay import SnakeGamePlay
from food import Food
from scoreboard import ScoreBoard
import time

screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("black")
screen.title("Snake Game")
positions = [(0, 0), (-20, 0), (-40, 0)]
initial_score = -1
screen.tracer(0)
snake = SnakeGamePlay(positions)
food = Food()
score = ScoreBoard(initial_score)

game_is_on = True
while game_is_on:
    screen.update()
    time.sleep(0.1)
    screen.listen()
    snake.move_snake()
    heading = snake.find_head_turtle()
    if heading == 0:
        screen.onkey(key="Up", fun=snake.turn_left)
        screen.onkey(key="Down", fun=snake.turn_right)
    elif heading == 90:
        screen.onkey(key="Left", fun=snake.turn_left)
        screen.onkey(key="Right", fun=snake.turn_right)
    elif heading == 180:
        screen.onkey(key="Up", fun=snake.turn_right)
        screen.onkey(key="Down", fun=snake.turn_left)
    else:
        screen.onkey(key="Left", fun=snake.turn_right)
        screen.onkey(key="Right", fun=snake.turn_left)

    # detect food collision
    if snake.turtle_head.distance(food) < 15:
        score.calculate_score()
        snake.extend_snake()
        food.refresh()
    # detect wall collision
    snake_xcor = round(snake.turtle_head.xcor())
    snake_ycor = round(snake.turtle_head.ycor())
    if snake_xcor == 300 or snake_xcor == -300 or snake_ycor == 300 or snake_ycor == -300:
        game_is_on = False
        score.display_end_game()

    # detect tail collision
    for turtle in snake.turtles[1:]:
        if snake.turtle_head.distance(turtle) < 10:
            game_is_on = False
            score.display_end_game()

screen.exitonclick()
