from turtle import Turtle

ALIGNMENT = "center"
FONT = ("Arial", 20, "normal")


class ScoreBoard(Turtle):
    def __init__(self, initial_score):
        super().__init__()
        self.hideturtle()
        self.goto(0, 270)
        self.color("white")
        self.initial_score = initial_score
        self.calculate_score()

    def calculate_score(self):
        self.initial_score += 1
        self.clear()
        self.write(f"Score: {self.initial_score}", move=False, align=ALIGNMENT, font=FONT)

    def display_end_game(self):
        self.goto(0, 0)
        self.write("Game Over.", move=False, align=ALIGNMENT, font=FONT)
