from turtle import Turtle

MOVE_DISTANCE = 20


class SnakeGamePlay:
    def __init__(self, positions):
        self.positions = positions
        self.turtles = []
        self.create_snake()
        self.turtle_head = self.turtles[0]

    def create_snake(self):
        for position in self.positions:
            self.add_snake(position)

    def add_snake(self, position):
        turtle_object = Turtle("square")
        turtle_object.color("white")
        turtle_object.penup()
        turtle_object.goto(position)
        self.turtles.append(turtle_object)

    def extend_snake(self):
        pos = self.turtles[-1].position()
        self.add_snake(pos)

    def move_snake(self):
        for turtle in range(len(self.turtles) - 1, 0, -1):
            new_xcor = self.turtles[turtle - 1].xcor()
            new_ycor = self.turtles[turtle - 1].ycor()
            self.turtles[turtle].goto(new_xcor, new_ycor)
        self.turtle_head.forward(MOVE_DISTANCE)

    def find_head_turtle(self):
        return self.turtle_head.heading()

    def turn_left(self):
        for turtle in self.turtles:
            turtle.left(90)

    def turn_right(self):
        for turtle in self.turtles:
            turtle.right(90)
