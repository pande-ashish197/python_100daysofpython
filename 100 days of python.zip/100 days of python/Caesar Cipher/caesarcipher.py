alphabets = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
             'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
game = True

while game:
    direction = input("Enter 'encode' to encrypt or 'decode' to decrypt the message: ")
    message = input("Enter your message: ").lower()
    shift = int(input("Type the shift number: "))
    output_message = ""
    for letter in message:
        if letter in alphabets:
            pos = alphabets.index(letter)
            if direction == 'encode':
                new_pos = pos+shift
                new_pos %= 26
                output_message += alphabets[new_pos]
            elif direction == 'decode':
                new_pos = pos - shift
                new_pos %= 26
                output_message += alphabets[new_pos]
            else:
                print("Incorrect Choice!")
        else:
            output_message += letter

    print(output_message)
    user_input = input("Do you want to continue Yes/No: ").lower()
    if user_input != 'yes':
        game = False
