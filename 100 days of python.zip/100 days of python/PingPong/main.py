from turtle import Screen, Turtle
import time
from handles import Handles
from ballmovement import BallMovement
from scoreboard import Scoreboard

screen = Screen()
screen.tracer(0)
l_paddle = Handles((-350, 0))
r_paddle = Handles((350, 0))
ball = BallMovement()
score = Scoreboard()


# divide screen
def create_screen():
    timmy = Turtle()
    timmy.setheading(270)
    timmy.pensize(3)
    timmy.hideturtle()
    timmy.color("white")
    for y in range(280, -280, -30):
        timmy.penup()
        timmy.goto(0, y)
        timmy.pendown()
        timmy.forward(20)


def detect_collision_with_paddle():
    if (ball.distance(r_paddle) < 50 and ball.xcor() > 320) or (ball.distance(l_paddle) < 50 and ball.xcor() < -320):
        ball.bounce_ball_from_paddle()


def detect_collision_with_wall():
    ball_ycor = ball.ycor()
    if ball_ycor > 280 or ball_ycor < -280:
        ball.bounce_ball_from_wall()


screen.setup(width=800, height=600)
screen.bgcolor("black")
screen.title("Ping Pong")
create_screen()
game_is_on = True

screen.listen()
screen.onkey(key="Up", fun=r_paddle.move_turtle_up)
screen.onkey(key="Down", fun=r_paddle.move_turtle_down)
screen.onkey(key="w", fun=l_paddle.move_turtle_up)
screen.onkey(key="s", fun=l_paddle.move_turtle_down)

while game_is_on:
    screen.update()
    time.sleep(0.1)
    ball.move_ball()
    detect_collision_with_paddle()
    detect_collision_with_wall()
    # ball outside right paddle
    if ball.xcor() > 380:
        ball.reset_ball_position()
        score.calculate_left_paddle_score()
    # ball outside left paddle
    if ball.xcor() < -380:
        ball.reset_ball_position()
        score.calculate_right_paddle_score()
screen.exitonclick()
