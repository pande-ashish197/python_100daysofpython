def add(num1, num2):
    return num1 + num2


def subtract(num1, num2):
    return num1 - num2


def multiply(num1, num2):
    return num1 * num2


def divide(num1, num2):
    return num1 / num2


operator = {
    '+': add,
    '-': subtract,
    '*': multiply,
    '/': divide
}


def calculator():
    n1 = int(input("What's the first number?: "))
    for items in operator.keys():
        print(items, sep="\n")
    game = True
    while game:
        op = input("Pick an operator: ")
        n2 = int(input("What's the next number?: "))
        result = operator[op](n1, n2)
        y_or_n = input(f"Type 'y' to continue calculating with {result}, or type 'n' to start a new calculator")
        if y_or_n == 'y':
            n1 = result
        elif y_or_n == 'n':
            game = False
            calculator()
        else:
            print("invalid pick")
            game = False


calculator()