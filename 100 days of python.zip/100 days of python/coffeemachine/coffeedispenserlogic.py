class CoffeeDispenser:
    def __init__(self, coffee_variant_data, machine_quantity_data, choice):
        self.coffee_variant_data = coffee_variant_data
        self.machine_quantity_data = machine_quantity_data
        self.pricing = {
            'quarters': 0.25,
            'dimes': 0.10,
            'nickles': 0.05,
            'pennies': 0.01
        }
        self.choice = choice

    def calculate_change(self):
        print("Please enter coins")
        quarters = int(input("how many quarters?: "))
        dimes = int(input("how many dimes?: "))
        nickles = int(input("how many nickles?: "))
        pennies = int(input("how many pennies?: "))
        total_user_money = quarters * self.pricing['quarters'] + dimes * self.pricing['dimes'] + nickles * self.pricing['nickles']+ \
            pennies * self.pricing['pennies']
        return total_user_money


    def coffee_dispenser_logic(self):
        if self.machine_quantity_data["Water"] >= self.coffee_variant_data["Water"] and self.machine_quantity_data[
            "Milk"] >= self.coffee_variant_data[
            "Milk"] and \
                self.machine_quantity_data["Coffee"] >= self.coffee_variant_data["Coffee"]:
            user_money = self.calculate_change()
            coffee_price = self.coffee_variant_data["Money"]
            if user_money >= coffee_price:
                change = user_money - coffee_price
                rounded_change = round(change, 2)
                print(f"Here is ${rounded_change}.")
                print(f"Here is your {self.choice}. Enjoy!")
                self.machine_quantity_data["Water"] -= self.coffee_variant_data["Water"]
                self.machine_quantity_data["Milk"] -= self.coffee_variant_data["Milk"]
                self.machine_quantity_data["Coffee"] -= self.coffee_variant_data["Coffee"]
                self.machine_quantity_data["Money"] += coffee_price
            else:
                print("Sorry that's not enough money. Money refunded.")
        else:
            if self.machine_quantity_data["Water"] < self.coffee_variant_data["Water"]:
                print("Water is less")
            elif self.machine_quantity_data["Milk"] < self.coffee_variant_data["Milk"]:
                print("Milk is less")
            else:
                print("Coffee is less")
