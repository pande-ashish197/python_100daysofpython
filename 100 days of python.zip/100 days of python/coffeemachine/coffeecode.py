from coffeemachine.data import coffee_data

coffee_machine = True


def coffee_machine_logic(machine_data, coffee_variant_data, choice):
    if machine_data["Water"] >= coffee_variant_data["Water"] and machine_data["Milk"] >= coffee_variant_data["Milk"] and \
            machine_data["Coffee"] >= coffee_variant_data["Coffee"]:
        print("Please enter coins")
        quarters = int(input("how many quarters?: "))
        dimes = int(input("how many dimes?: "))
        nickles = int(input("how many nickles?: "))
        pennies = int(input("how many pennies?: "))
        total_user_money = (0.25 * quarters) + (0.10 * dimes) + (0.05 * nickles) + (0.01 * pennies)
        coffee_price = coffee_variant_data["Money"]
        if total_user_money >= coffee_price:
            change = total_user_money - coffee_price
            rounded_change = round(change, 2)
            print(f"Here is ${rounded_change}.")
            print(f"Here is your {choice}. Enjoy!")
            machine_data["Water"] -= coffee_variant_data["Water"]
            machine_data["Milk"] -= coffee_variant_data["Milk"]
            machine_data["Coffee"] -= coffee_variant_data["Coffee"]
            machine_data["Money"] += coffee_price
        else:
            print("Sorry that's not enough money. Money refunded.")
    else:
        if machine_data["Water"] < coffee_variant_data["Water"]:
            print("Water is less")
        elif machine_data["Milk"] < coffee_variant_data["Milk"]:
            print("Milk is less")
        else:
            print("Coffee is less")


while coffee_machine:
    choice = input("What would you like? (espresso/latte/cappuccino): ").lower()
    if choice == 'report':
        for items in coffee_data["coffee_machine_quantity_left"]:
            if items != 'Money':
                print(f"{items}: {coffee_data['coffee_machine_quantity_left'][items]}ml")
            else:
                print(f"{items}: ${coffee_data['coffee_machine_quantity_left'][items]}")
    elif choice == 'off':
        coffee_machine = False
    else:
        user_choice_data = coffee_data[choice]
        machine_quantity_data = coffee_data['coffee_machine_quantity_left']
        coffee_machine_logic(machine_quantity_data, user_choice_data, choice)
