from coffeemachine.data import coffee_data
from coffeedispenserlogic import CoffeeDispenser

coffee_machine = True


class CoffeeMachineUserChoice:
    def __init__(self, user_choice, coffee_data):
        self.user_choice = user_choice
        self.coffee_data = coffee_data

    def create_report(self):
        if self.user_choice == 'report':
            for items in self.coffee_data["coffee_machine_quantity_left"]:
                if items != "Money" and items != "Coffee":
                    print(f"{items}: {coffee_data['coffee_machine_quantity_left'][items]}ml")
                elif items == "Coffee":
                    print(f"{items}: {coffee_data['coffee_machine_quantity_left'][items]}g")
                else:
                    print(f"{items}: ${coffee_data['coffee_machine_quantity_left'][items]}")
        elif self.user_choice == "off":
            global coffee_machine
            coffee_machine = False
        else:
            user_choice_data = self.coffee_data[self.user_choice]
            machine_quantity_data = self.coffee_data['coffee_machine_quantity_left']
            coffee = CoffeeDispenser(user_choice_data, machine_quantity_data, self.user_choice)
            coffee.coffee_dispenser_logic()

while coffee_machine:
    choice = input("What would you like? (espresso/latte/cappuccino): ").lower()
    obj1 = CoffeeMachineUserChoice(choice, coffee_data)
    obj1.create_report()
