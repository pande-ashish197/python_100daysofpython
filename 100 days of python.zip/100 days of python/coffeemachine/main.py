from coffemachineuserchoice import CoffeeMachineUserChoice

