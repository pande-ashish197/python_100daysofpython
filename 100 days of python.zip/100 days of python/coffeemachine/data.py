coffee_data = {
    "coffee_machine_quantity_left": {
        "Water": 300,
        "Milk": 200,
        "Coffee": 100,
        "Money": 0
    },
    "espresso": {
        "Water": 50,
        "Milk": 0,
        "Coffee": 18,
        "Money": 1.50
    },
    "latte": {
        "Water": 200,
        "Milk": 150,
        "Coffee": 24,
        "Money": 2.50
    },
    "cappuccino": {
        "Water": 250,
        "Milk": 100,
        "Coffee": 24,
        "Money": 3.00
    }
}

