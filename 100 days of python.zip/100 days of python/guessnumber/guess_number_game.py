import random

random_number = random.randint(1, 100)
hard_level = 5
easy_level = 10
print(random_number)
print("Welcome to the Number guessing game!")
print("I'm thinking of a number between 1 and 100.")


def guess_the_number():
    level = input("Choose a difficulty level. Type 'easy' or 'hard': ")
    if level == 'hard':
        answer = game_play(hard_level)
    elif level == 'easy':
        answer = game_play(easy_level)
    else:
        print("invalid entry")

    if answer == 1:
        print(f"You got it! The answer was {random_number} ")
    else:
        print("You rant out of attempts ")


def game_play(player_level):
    while player_level != 0:
        print(f"You have {player_level} attempts to guess the number.")
        guess = int(input("Make a guess: "))
        if guess == random_number:
            return 1
        elif guess > random_number:
            answer = "Too high."
            #print("Too high. Guess again")
            #return game_play(player_level-1)
        else:
            answer = "Too Low."
            #print("Too low. Guess again")
            ##return game_play(player_level-1)

        if player_level > 1:
            print(answer)
            print("Guess again")
            return game_play(player_level-1)
        else:
            print(answer)
            return game_play(player_level-1)

guess_the_number()