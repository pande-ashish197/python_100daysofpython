from blackjack.art import logo
import random

card_deck = [11, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]


def game_play(playercards, dealercards, player_total, dealer_total):
    print(playercards,dealercards, player_total, dealer_total)
    player_flag = True
    player_total = sum(playercards)
    print("Your total=", player_total)
    dealer_total = sum(dealercards)
    print(f"dealer {dealer_total}")
    if player_total < 21:
        print(f"Your cards: {playercards}, current score ={player_total}")
        print(f"Computer's first card: {dealercards[0]}")
        user_choice = input("Type 'y' to draw another card or 'n' to stand").lower()
        if user_choice == 'y':
            playercards.append(random.choice(card_deck))
            game_play(playercards, dealercards, player_total, dealer_total)
        else:
            if dealer_total == 21:
                print("Blackjack. Dealer Wins!")
                player_flag = False
            else:
                while dealer_total < 21:
                    dealercards.append(random.choice(card_deck))
                    print(dealercards)
                    dealer_total = sum(dealercards)
                    print(f"Dealer cards: {dealercards}, current score ={dealer_total}")
                    #print("dealer total=", dealer_total)
                    if player_total < dealer_total <= 21:
                        player_flag = False
                        print("hahahaa")
                    else:
                        player_flag = True
                        print("buhhaaahhaaa")
                else:
                    if 11 in dealercards:
                        A_dealerindex = dealercards.index(11)
                        dealercards[A_dealerindex] = 1
                        game_play(playercards, dealercards, player_total, dealer_total)
                #return player_flag
    elif player_total == 21:
        print("Blackjack. You Win!")
        player_flag = True
        #return player_flag
    else:
        if 11 in playercards:
            A_index = playercards.index(11)
            playercards[A_index] = 1
            game_play(playercards, dealercards, player_total, dealer_total)
        else:
            player_flag = False
            #return player_flag
    print("Isko return karo=",player_flag)
    return player_flag


def blackjack():
    game = True
    player_score = 0
    dealer_score = 0
    player_cards = []
    dealer_cards = []
    while game:
        play_game = input("Do you want to play a game of Blackjack? Type 'y' or 'n':").lower()
        if play_game == 'y':
            print(logo)
            player_cards = [random.choice(card_deck) for i in range(2)]
            print(player_cards)
            dealer_cards = [random.choice(card_deck) for i in range(2)]
            answer = game_play(player_cards, dealer_cards, player_score, dealer_score)
            print("Ye answer hai=", answer)
            if answer:
                print("You win")
            else:
                print("Dealer wins")
            blackjack()
        elif play_game == 'n':
            game = False
        else:
            print("invalid choice")
            game = False


blackjack()
