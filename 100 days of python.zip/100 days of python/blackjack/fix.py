a = "8=FIX.4.2|9=230|10=241|11=yFd0002|12=0.00000000|13=1|15=USD|21=3|34=8|35=D|38=100|40=2|44=150.00000000|47=P|49=CLNTMACQ|50=PTS|52=20210629-18:10:04|54=1|55=IBM|56=LINKMACQ|60=20210629-18:10:04|63=0|64=20210702|109=AAA-FIX-44|120=USD|155=0.000000|167=CS|".split("|")
message_dictionary = {}
for items in a:
    t = items.rpartition("=")
    message_dictionary[t[0]] = t[2]
print(message_dictionary)
message_dictionary.pop("47")
new_message = ""
for i in message_dictionary:
    #print(i,message_dictionary[i])
    word = ("{}={}".format(i, message_dictionary[i]))
    new_message += ("{}{}".format(word,"|"))
print(new_message)