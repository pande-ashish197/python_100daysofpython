from turtle import Turtle, Screen

timmy = Turtle()
screen = Screen()
screen.title("""
                W = Forward,
                S = Backward,
                A = Counter-Clockwise,
                D = Clockwise,
                C = Clear""")


def forward():
    timmy.forward(10)


def backward():
    timmy.backward(10)


def counterclockwise():
    timmy.left(6)


def clockwise():
    timmy.right(6)


def clear():
    timmy.clear()
    timmy.penup()
    timmy.home()
    timmy.pendown()


screen.listen()
screen.onkey(key="W", fun=forward)
screen.onkey(key="S", fun=backward)
screen.onkey(key="A", fun=counterclockwise)
screen.onkey(key="D", fun=clockwise)
screen.onkey(key="C", fun=clear)
screen.exitonclick()
