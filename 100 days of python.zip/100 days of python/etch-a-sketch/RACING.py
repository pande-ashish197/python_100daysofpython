import turtle as t
from racinggameplay import RacingGame

timmy = t.Turtle()
tommy = t.Turtle()
tammy = t.Turtle()
temmy = t.Turtle()
tummy = t.Turtle()
# timmy.color("red")
# tommy.color("blue")
# tammy.color("green")
# temmy.color("orange")
# tummy.color("yellow")
turtles = [timmy, tommy, tammy, temmy, tummy]
colors = ["red", "blue", "green", "orange", "yellow"]
screen = t.Screen()
screen.setup(width=500, height=400)
user_guess = screen.textinput(title="Place your bet", prompt="Which turtle will win the race! Enter color: ")
print(user_guess)
game = RacingGame(turtles, colors, user_guess)
game.define_shape()
game.set_color()
game.starting_pos()
game.game_play()

screen.exitonclick()
