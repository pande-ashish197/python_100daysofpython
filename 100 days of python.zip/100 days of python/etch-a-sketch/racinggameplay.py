import random

class RacingGame:
    def __init__(self, turtle_objects, turtle_colors, user_guess):
        self.turtle_objects = turtle_objects
        self.turtle_colors = turtle_colors
        self.user_guess = user_guess

    def define_shape(self):
        for i in self.turtle_objects:
            i.shape("turtle")

    def starting_pos(self):
        y = -125
        for i in self.turtle_objects:
            i.penup()
            i.goto(-240, y)
            y += 50

    def set_color(self):
        color_index = 0
        for i in self.turtle_objects:
            i.color(self.turtle_colors[color_index])
            color_index += 1

    def game_play(self):
        is_race_on = True
        while is_race_on:
            for i in self.turtle_objects:
                if i.xcor() > 230:
                    is_race_on = False
                    if i.pencolor() == self.user_guess:
                        print(f"Winner is:{i.pencolor()}")
                        print("You Won")
                    else:
                        print("You lost")
                else:
                    distance = random.randint(0, 10)
                    i.forward(distance)
