from prettytable import PrettyTable

x= PrettyTable()
x.field_names = ["S.No", "Pokemon_Name", "Pokemon_Type"]
x.add_row(["1", "Pikachu", "Electric"])
x.add_row(["2", "Squirtle", "Water"])
x.add_row(["3", "Charmander", "Fire"])
x.add_row(["1", "Bulbasaur", "Grass"])
print(x)


