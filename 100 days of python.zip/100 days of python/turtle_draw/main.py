from turtle import Turtle, Screen
from drawTurtle import DrawTurtle
import random

tim = Turtle()
sides = [3, 4, 5, 6, 7, 8, 9, 10]
colours = ["CornflowerBlue", "DarkOrchid", "IndianRed", "DeepSkyBlue", "LightSeaGreen", "wheat", "SlateGray",
           "SeaGreen"]
direction_flag = ["forward(20)", "backward(20)", "right(20)", "left(20)"]
tim.shape("turtle")

size_of_gap = 15
for _ in range(int(360/size_of_gap)):
    color = random.choice(colours)
    tim.color(color)
    draw = DrawTurtle(tim, sides, size_of_gap)
    #draw.draw_square()
    draw.draw_spirograph()
# draw.draw_dashed_line()
# for _ in range(500):
#     color = random.choice(colours)
#     tim.color(color)
#     draw1 = DrawTurtle(tim, sides)
#     draw1.generate_random_walk()


screen = Screen()
screen.exitonclick()
