import random


class DrawTurtle:
    def __init__(self, timmy, side, size_of_gap):
        self.timmy = timmy
        self.side = side
        self.direction = ["forward", "backward", "right", "left"]
        self.size_of_gap = size_of_gap

    def draw_square(self):
        for _ in range(4):
            self.timmy.right(45)
            self.timmy.forward(50)


    def draw_dashed_line(self):
        for _ in range(10):
            self.timmy.forward(10)
            self.timmy.penup()
            self.timmy.forward(10)
            self.timmy.pendown()

    def draw_different_shapes(self):
        angle = 360 / self.side
        for _ in range(self.side):
            self.timmy.forward(50)
            self.timmy.right(angle)

    def generate_random_walk(self):
        direct = random.choice(self.direction)
        self.timmy.pensize(10)
        self.timmy.speed("fastest")
        if direct == "forward":
            self.timmy.forward(20)
        elif direct == "backward":
            self.timmy.backward(20)
        elif direct == "right":
            self.timmy.right(90)
        else:
            self.timmy.left(90)

    def draw_spirograph(self):
        # self.timmy.hideturtle()
        #self.timmy.speed("fastest")
        self.timmy.circle(100)
        self.timmy.left(self.size_of_gap)
