from higherlower import art
from higherlower.data import data
import random

A = random.choice(data)
game = True
score = 0
def input_choice():
    B = random.choice(data)
    game_play(B)

def game_play(B):
    global A, game, score
    while game:
        print(f"Compare A: {A['name']}, {A['description']}, from {A['country']}.")
        print(art.vs)
        print(f"Against B: {B['name']}, {B['description']}, from {B['country']}.")
        choice = input("Who has more followers? Type 'A' or 'B': ")
        if choice == 'A':
            if A['follower_count'] > B['follower_count']:
                score += 1
                print(f"You're right! Current score: {score}")
                A = B
                input_choice()
            else:
                print(f"Sorry, that's wrong. Final score: {score}")
                game = False
        elif choice == 'B':
            if B['follower_count'] > A['follower_count']:
                score += 1
                print(f"You're right! Current score: {score}")
                A = B
                input_choice()
            else:
                print(f"Sorry, that's wrong. Final score: {score}")
                game = False


input_choice()
