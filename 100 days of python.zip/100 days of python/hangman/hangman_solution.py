import random
from hangman import hangman_words
from hangman import hangman_art


def hangman_solution():
    word = random.choice(hangman_words.word_list)
    print(word)
    tries = 0
    guessed_letter = []
    guessed = False
    original_list = list("_" * len(word))
    while not guessed and tries < len(hangman_art.stages):
        guess_character = input('Guess a letter: ')
        if guess_character in guessed_letter:
            print("You have already guessed this letter")
        elif guess_character not in word:
            print(hangman_art.stages[tries])
            tries += 1
        else:
            guessed_letter.append(guess_character)
            position = [i for i, letter in enumerate(word) if letter == guess_character]
            for index in position:
                original_list[index] = guess_character
                guessed_string = "".join(original_list)
                print(guessed_string)
                if guessed_string == word:
                    guessed = True
        if guessed:
            print("You have guessed the correct word. You Won!")
    else:
        print("You Lost")


print("Welcome to Hangman Game")
user_choice = input("Do you want to continue Y/N: ").upper()
if user_choice == 'Y':
    hangman_solution()
else:
    print("Game Over")

